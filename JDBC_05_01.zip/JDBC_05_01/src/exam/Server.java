package exam;

public class Server {
	
	public Server() {
		
	}
	
	public static void main(String[] args) {
		
	}
}
