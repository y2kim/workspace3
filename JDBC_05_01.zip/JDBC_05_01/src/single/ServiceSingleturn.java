package single;

import service.Service;
//싱글톤 
public class ServiceSingleturn {
	
	private static Service instance;
	
}
